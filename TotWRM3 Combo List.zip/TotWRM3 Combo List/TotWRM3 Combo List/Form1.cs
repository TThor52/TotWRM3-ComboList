﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TotWRM3_Combo_List
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Global Variables:
        List<string> comboList = new List<string>();
        Action referenceBTNMethods;

        //Methods:
        private DialogResult YesNoMessageBox(string message, string caption)
        {
            return MessageBox.Show(message, caption,
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question);
        }

        private void CheckFileExists(string filePath, Character c)
        {
            if (File.Exists(filePath) == false)
            {
                string message = "The save file does not exist, create a new one?",
                       caption = "Save file does not exist";

                if (YesNoMessageBox(message, caption) == DialogResult.Yes)
                    SaveCharactertoFile(filePath, c);
                else
                    MessageBox.Show("Save cancelled");
            }
            else
            {
                string message = "A save file already exists, overwrite it?",
                       caption = "Save file already exists";

                if (YesNoMessageBox(message, caption) == DialogResult.Yes)
                    SaveCharactertoFile(filePath, c);
                else
                    MessageBox.Show("Save cancelled");
            }
        }

        private void SaveCharactertoFile(string filePath, Character c)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Append, FileAccess.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    int counter = 1;
                    sw.WriteLine(c.Name);
                    foreach (string arte in c.ComboList)
                    {
                        sw.WriteLine(counter + ": " + arte);
                        counter++;
                    }
                }
            }
            MessageBox.Show("The file was saved succesfully.", "File save successful");
        }

        //Methods for buttons
        private void btnAddArteMethod()
        {
            //Clear lvComboList
            lvComboList.Items.Clear();

            //Get arte from txtArteName
            string newArte = txtArteName.Text;
            //Add arte to comboList if there was something typed
            if (newArte != "")
            {
                comboList.Add(newArte);

                for (int i = 0; i < comboList.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem((i + 1).ToString());
                    lvi.SubItems.Add(comboList[i]);

                    lvComboList.Items.Add(lvi);
                }

                txtArteName.Text = String.Empty;
            }
            else
                MessageBox.Show("Please type an arte's name.", "No arte name was typed.");
        }

        private void btnSaveComboListMethod()
        {
            //Get name from text box
            string characterName = txtCharacterName.Text;

            //Check if a name was typed
            if (characterName != "")
            {
                //Set the path and file
                string filePath = Path.Combine(Environment.CurrentDirectory, "CharacterComboList.txt");

                //Make a new character based on the name and the combo list
                Character newCharacter = new Character(characterName);

                //Looping through the specific column in lvComboList and
                //adding that to the combo list in newCharacter
                foreach (ListViewItem lvi in lvComboList.Items)
                    newCharacter.AddArte(lvi.SubItems[1].Text);

                //Save everything to a text file
                CheckFileExists(filePath, newCharacter);

                lblCharacterName.Visible = true;
                lblCharacterName.Text = characterName;
            }
            else
                MessageBox.Show("Please type a character name.");
        }

        //Controls:
        private void btnAddArte_Click(object sender, EventArgs e)
        {
            referenceBTNMethods = btnAddArteMethod;
            Invoke(referenceBTNMethods);
        }

        private void btnSaveComboList_Click(object sender, EventArgs e)
        {
            referenceBTNMethods = btnSaveComboListMethod;
            Invoke(referenceBTNMethods);
        }

        //Miscellanious
        private void txtArteName_Enter(object sender, EventArgs e)
        {
            txtCharacterName.TabStop = false;
            btnSaveComboList.TabStop = false;

            txtArteName.TabStop = true;
            btnAddArte.TabStop = true;
        }

        private void txtCharacterName_Enter(object sender, EventArgs e)
        {
            txtCharacterName.TabStop = true;
            btnSaveComboList.TabStop = true;

            txtArteName.TabStop = false;
            btnAddArte.TabStop = false;
        }
    }
}
