﻿namespace TotWRM3_Combo_List
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCharacterName = new System.Windows.Forms.Label();
            this.lvComboList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label3 = new System.Windows.Forms.Label();
            this.txtArteName = new System.Windows.Forms.TextBox();
            this.btnAddArte = new System.Windows.Forms.Button();
            this.btnSaveComboList = new System.Windows.Forms.Button();
            this.pnlSave = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCharacterName = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.pnlSave.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pnlSave);
            this.panel1.Controls.Add(this.btnAddArte);
            this.panel1.Controls.Add(this.txtArteName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lvComboList);
            this.panel1.Controls.Add(this.lblCharacterName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(540, 472);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Combo list for:";
            // 
            // lblCharacterName
            // 
            this.lblCharacterName.AutoSize = true;
            this.lblCharacterName.Location = new System.Drawing.Point(149, 11);
            this.lblCharacterName.Name = "lblCharacterName";
            this.lblCharacterName.Size = new System.Drawing.Size(147, 24);
            this.lblCharacterName.TabIndex = 1;
            this.lblCharacterName.Text = "Character Name";
            this.lblCharacterName.Visible = false;
            // 
            // lvComboList
            // 
            this.lvComboList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvComboList.FullRowSelect = true;
            this.lvComboList.GridLines = true;
            this.lvComboList.Location = new System.Drawing.Point(18, 38);
            this.lvComboList.Name = "lvComboList";
            this.lvComboList.Size = new System.Drawing.Size(257, 417);
            this.lvComboList.TabIndex = 2;
            this.lvComboList.TabStop = false;
            this.lvComboList.UseCompatibleStateImageBehavior = false;
            this.lvComboList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 30;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Arte Name";
            this.columnHeader2.Width = 210;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(281, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Arte Name:";
            // 
            // txtArteName
            // 
            this.txtArteName.Location = new System.Drawing.Point(381, 35);
            this.txtArteName.Name = "txtArteName";
            this.txtArteName.Size = new System.Drawing.Size(140, 28);
            this.txtArteName.TabIndex = 0;
            this.txtArteName.Enter += new System.EventHandler(this.txtArteName_Enter);
            // 
            // btnAddArte
            // 
            this.btnAddArte.Location = new System.Drawing.Point(401, 69);
            this.btnAddArte.Name = "btnAddArte";
            this.btnAddArte.Size = new System.Drawing.Size(100, 36);
            this.btnAddArte.TabIndex = 1;
            this.btnAddArte.Text = "Add Arte";
            this.btnAddArte.UseVisualStyleBackColor = true;
            this.btnAddArte.Click += new System.EventHandler(this.btnAddArte_Click);
            // 
            // btnSaveComboList
            // 
            this.btnSaveComboList.Location = new System.Drawing.Point(18, 77);
            this.btnSaveComboList.Name = "btnSaveComboList";
            this.btnSaveComboList.Size = new System.Drawing.Size(192, 36);
            this.btnSaveComboList.TabIndex = 3;
            this.btnSaveComboList.Text = "Save Combo List";
            this.btnSaveComboList.UseVisualStyleBackColor = true;
            this.btnSaveComboList.Click += new System.EventHandler(this.btnSaveComboList_Click);
            // 
            // pnlSave
            // 
            this.pnlSave.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlSave.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSave.Controls.Add(this.txtCharacterName);
            this.pnlSave.Controls.Add(this.btnSaveComboList);
            this.pnlSave.Controls.Add(this.label4);
            this.pnlSave.Location = new System.Drawing.Point(290, 111);
            this.pnlSave.Name = "pnlSave";
            this.pnlSave.Size = new System.Drawing.Size(231, 130);
            this.pnlSave.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Enter the Character\'s Name:";
            // 
            // txtCharacterName
            // 
            this.txtCharacterName.Location = new System.Drawing.Point(18, 43);
            this.txtCharacterName.Name = "txtCharacterName";
            this.txtCharacterName.Size = new System.Drawing.Size(192, 28);
            this.txtCharacterName.TabIndex = 2;
            this.txtCharacterName.Enter += new System.EventHandler(this.txtCharacterName_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(568, 496);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlSave.ResumeLayout(false);
            this.pnlSave.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lvComboList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label lblCharacterName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddArte;
        private System.Windows.Forms.TextBox txtArteName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlSave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSaveComboList;
        private System.Windows.Forms.TextBox txtCharacterName;
    }
}

