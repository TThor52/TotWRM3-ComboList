﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TotWRM3_Combo_List
{
    public class Character
    {
        private string _name;
        private List<string> _comboList;

        public Character(string name)
        {
            _name = name;
            _comboList = new List<string>();
        }

        public string Name { get { return _name; } }
        public string[] ComboList { get { return _comboList.ToArray(); } }

        public void AddArte(string arte)
        {
            _comboList.Add(arte);
        }
    }
}
